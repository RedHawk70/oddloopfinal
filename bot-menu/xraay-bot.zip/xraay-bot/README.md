# xraay-bot — Bot Telegram CONFIG LIST (Panel Xray VLESS)

Bot Telegram untuk bahagian **PANEL XRAY VLESS WEBSOCKET TLS**. User hantar
**User ID (UUID)**, bot auto-detect user dalam server, lepas tu papar semua
config yang ada dalam **CONFIG LIST** VPS ikut nama telco.

```
👤 User: alice
📅 Expired: 2026-11-30
📡 Config List: 3 telco • 4 config
━━━━━━━━━━━━━━━━━━━━
Note : Promosi bulan ini — topup 30 hari dapat 5 hari free.

🟡DIGI LIVE/EXP
Note : Khas DIGI — topup 30 hari, dapat 5 hari free.
┌─────────────────────────────
│ vless://ee89fe76-...@104.18.21.212:80?path=%2Fvless&security=none&...
└─────────────────────────────

🔵CELCOM BYPASS CAPPED PLAN UNLIMITED
┌─────────────────────────────
│ vless://ee89fe76-...@nga.celcomdigi.com.s1.nullbytes.vip:80?path=...
└─────────────────────────────
```

(link dalam *quote + monospace* → tekan je untuk copy)

---

## Apa bot ni buat

1. User hantar UUID → bot cari dalam
   `/usr/local/etc/xray/config.json` dan `/usr/local/etc/xray/none.json`
2. Bot baca `/etc/xray/configlist/<telco>.conf` — **fail yang sama** yang
   panel `xraay` guna. Tak sentuh langsung script panel.
3. Bina semula link VLESS untuk UUID tersebut.
4. Papar ikut **nama config** dalam fail tu, dengan emoji warna telco yang
   sama macam warna panel (ANSI 256 → emoji bulat).
5. **Hanya telco yang betul-betul ada config** dipaparkan. Kalau `yes.conf`
   kosong atau tiada, `Yes` tak muncul sama sekali.

Susunan telco ikut panel: `umobile, yes, digi, celcom, maxis, eastel,
yoodo, tunetalk, tonewow, redone`.

---

## Panel Admin & Note

Admin boleh letak **Note** yang muncul pada **setiap** reply config list,
terus di bawah garis pemisah. Berguna untuk bagi arahan/peringatan kepada
pelanggan tanpa ubah kod.

### Hidupkan akses admin

1. Hantar `/admin` pada bot (walaupun belum admin) — bot akan balas chat ID kau:
   ```
   ⛔ Kau bukan admin.
   Chat ID kau: 123456789
   ```
2. Masukkan ID tu:
   ```bash
   nano /etc/xraay-bot/config.json
   # "admin_ids": [123456789],
   systemctl restart xraay-bot
   ```
3. Hantar `/admin` lagi → panel keluar.

> Guna `/admin` untuk dapat ID — tak perlu fikir sendiri macam mana nak cari.

### Arahan admin

| Arahan | Fungsi |
|---|---|
| `/admin` | Buka panel (butang: Lihat / Tukar / Padam / Tutup) |
| `/setnote <teks>` | Terus set note |
| `/setnote` | Bot minta teks note (boleh berbilang baris) |
| `/note` | Lihat note semasa |
| `/delnote` | Padam note |
| `/cancel` | Batal semasa taip note |

Had panjang note: **800 aksara** (`note_max_len` dalam config).

### Note per-config

Selain note umum, boleh letak note pada **config tertentu** — muncul terus
bawah nama config:

```
🟣YES LIVE/EXP-S1
Note : Khas YES — promo bulan ini.
vless://...
```

Cara: `/admin` → **📌 Note Config** → pilih config → **✏️ Tukar Note** →
hantar teks.

| Butang | Fungsi |
|---|---|
| 📌 Note Config | Senarai semua config (ikut telco & warna) |
| ✏️ Tukar Note | Set note untuk config yang dipilih |
| 🗑 Padam Note | Buang note config tu |
| ⬅️ Kembali | Balik ke senarai / panel |

Note per-config **tidak bercampur** — note DIGI tak muncul pada CELCOM.
Kalau config dipadam dari CONFIG LIST, note dia tinggal dalam fail (tak
mengganggu apa-apa).

### Di mana note disimpan

`/var/lib/xraay-bot/note.txt` (note umum)
`/var/lib/xraay-bot/config-notes.json` (note per-config)

Bukan dalam `/etc` sebab service guna `ProtectSystem=full` — `/etc` read-only
untuk bot. Kalau nak edit manual pun boleh:

```bash
nano /var/lib/xraay-bot/note.txt
# terus berkesan pada reply seterusnya, tak perlu restart
```

---

## Menu urus di VPS

Selepas install, ada satu menu untuk urus semua — tak payah hafal arahan:

```bash
xraay-bot-menu
```

```
   ╔══════════════════════════════════════════════╗
   ║      BOT CONFIG LIST VLESS — PANEL URUS      ║
   ╚══════════════════════════════════════════════╝

   Status       : ● RUNNING
   Token        : 9253686527:…
   Admin        : 1 ID
   Note umum    : ada
   Note config  : 2
   Config list  : 5 telco / 9 config

   ┌── PEMASANGAN ────────────────────────────────
   │  [1] Install / Update bot
   │  [2] Set / Tukar token bot
   └──────────────────────────────────────────────
   ┌── PERKHIDMATAN ──────────────────────────────
   │  [3] Status terperinci
   │  [4] Start / Stop / Restart
   └──────────────────────────────────────────────
   ┌── AKSES ─────────────────────────────────────
   │  [5] Urus admin
   │  [6] Urus allowlist pengguna
   └──────────────────────────────────────────────
   ┌── NOTE ──────────────────────────────────────
   │  [7] Note umum
   │  [8] Note per-config
   └──────────────────────────────────────────────
   ┌── LAIN-LAIN ─────────────────────────────────
   │  [9] Uji carian User ID
   │  [10] Papar config semasa
   │  [11] Log bot
   │  [12] Uninstall
   │  [0]  Keluar
   └──────────────────────────────────────────────
```

| Pilihan | Apa dia buat |
|---|---|
| 1 | Pasang / kemas kini `bot.py` & service (auto cari `bot.py` berdekatan) |
| 2 | Tukar token — **diuji dengan `getMe`** sebelum disimpan |
| 3 | Status service + semakan binari, JSON, config list, `log-install.txt` |
| 4 | Start / Stop / Restart |
| 5 | Tambah / buang admin (auto restart service) |
| 6 | Kawal siapa boleh guna bot (allowlist) |
| 7 | Note umum — set, edit guna nano, atau padam |
| 8 | Note per-config — senarai config + status note, set/padam |
| 9 | Uji carian User ID (sama macam `--dump`, terus nampak hasil) |
| 10 | Papar config semasa (token di-mask) |
| 11 | Log bot (40 baris atau ikut langsung) |
| 12 | Uninstall (tanya dulu sebelum buang config & note) |

Kalau menu belum ada (install lama), boleh run terus dari folder:

```bash
bash menu.sh
```

## Keperluan

- VPS yang dah ada panel `xraay` (fail `/etc/xray/configlist/*.conf`)
- Python 3 (installer auto-pasang kalau tiada)
- Token bot dari [@BotFather](https://t.me/BotFather)

---

## Cara install

Upload folder ni ke VPS, kemudian:

```bash
cd xraay-bot
bash install.sh
```

Installer akan tanya token bot, pasang ke `/usr/local/bin/xraay-bot`,
daftar service systemd, dan start automatik.

Ujian tanpa Telegram (paling berguna untuk verify dulu):

```bash
xraay-bot --dump ee89fe76-4b35-4b25-835d-d6d141b93bf7
```

Kalau output nampak betul, barulah masuk Telegram.

Buang balik:

```bash
bash install.sh --uninstall
```

---

## Config (`/etc/xraay-bot/config.json`)

| Field | Maksud |
|---|---|
| `bot_token` | Token dari BotFather |
| `allowed_chat_ids` | Senarai chat ID dibenarkan guna bot. `[]` = terbuka |
| `admin_ids` | Chat ID yang boleh guna panel admin |
| `configlist_dir` | Default `/etc/xray/configlist` |
| `xray_configs` | Fail config untuk cari UUID |
| `log_install` | Sumber port (`/root/log-install.txt`) |
| `fragment_style` | `name` = `#DIGI%20LIVE%2FEXP`<br>`name-srv` = `#DIGI%20LIVE%2FEXP-S1` |
| `note_file` | Lokasi fail note umum |
| `config_note_file` | Lokasi fail note per-config |
| `note_max_len` | Had aksara setiap note (lalai 800) |
| `display_server_tag` | `true` = nama config dipapar dengan tag server (`YES LIVE/EXP-S1`) |
| `ports` | Port lalai; ditimpa automatik dari `log-install.txt` |

Port dibaca dari `~/log-install.txt` (label `Vless Ws Tls`,
`Vless Ws None Tls`, `Xray HttpUpgrade Tls`, `Xray Vless Xhttp Tls`, dll).
Kalau fail tu tiada, guna lalai 443 (TLS) / 80 (None TLS).

Selepas ubah config:

```bash
systemctl restart xraay-bot
```

---

## Keselamatan

Bot ni dedah UUID akaun. Kalau bot ni untuk kegunaan sendiri / reseller
tertentu, isi `allowed_chat_ids` supaya orang lain tak boleh query:

```json
"allowed_chat_ids": [123456789, 987654321]
```

`admin_ids` pula kawal siapa boleh ubah Note. Jangan letak ID orang lain
sebagai admin — note dipaparkan kepada semua pengguna bot.

---

## Troubleshooting

```bash
systemctl status xraay-bot          # status
journalctl -u xraay-bot -f          # log langsung
xraay-bot --dump <UUID>             # uji tanpa Telegram
```

| Masalah | Punca biasa |
|---|---|
| `User ID tak dijumpai` | UUID salah, atau user dah dipadam |
| `Tiada config dalam CONFIG LIST` | `/etc/xray/configlist/` kosong / semua entry mode `vmess` |
| Bot senyap, log `got multiple values for keyword argument` | Versi lama — kemas kini `bot.py` |
| Note tak muncul | Fail note kosong, atau bot tak boleh tulis ke `/var/lib/xraay-bot` |
| Note config tak muncul | Config tu dah dipadam/dinamakan semula — set semula melalui panel |
| `Bukan admin` | Chat ID belum masuk `admin_ids`, atau belum restart |

---

## Struktur fail

```
xraay-bot/
├── bot.py               # bot (stdlib Python 3, tiada dependency)
├── menu.sh              # menu urus interactive
├── config.example.json  # contoh config
├── xraay-bot.service    # systemd unit
├── install.sh           # installer / uninstaller
└── README.md
```
