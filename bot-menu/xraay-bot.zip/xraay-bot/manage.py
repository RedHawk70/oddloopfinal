#!/usr/bin/env python3
"""Pembantu menu interaktif xraay-bot. Semua operasi guna pustaka standard."""
import json
import os
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
CONF = Path(os.environ.get("XRAY_BOT_CONFIG", "/etc/xraay-bot/config.json"))
EXAMPLE = BASE / "config.example.json"
sys.path.insert(0, str(BASE))
import bot  # noqa: E402


def raw_config():
    if not CONF.exists():
        return json.loads(EXAMPLE.read_text(encoding="utf-8"))
    try:
        data = json.loads(CONF.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        print("Config rosak atau tak boleh dibaca: %s" % CONF, file=sys.stderr)
        raise SystemExit(2)


def save_config(data):
    defaults = json.loads(EXAMPLE.read_text(encoding="utf-8"))
    defaults.update(data)
    data = defaults
    CONF.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONF.with_suffix(CONF.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, CONF)


def cfg():
    return bot.load_config(str(CONF))


def note_count():
    notes = bot.load_cnotes(cfg())
    return sum(1 for value in notes.values() if str(value).strip())


def summary():
    data = raw_config()
    config = cfg()
    token = str(data.get("bot_token") or "")
    displayed_token = token if token else "belum diset"
    groups = bot.collect_configs(config)
    count = sum(len(entries) for _, _, entries in groups)
    print("Token\t%s" % displayed_token)
    print("Admin\t%d ID" % len(data.get("admin_ids") or []))
    print("Note umum\t%s" % ("ada" if bot.read_note(config) else "tiada"))
    print("Note config\t%d" % note_count())
    print("Config list\t%d telco / %d config" % (len(groups), count))
    allowed = data.get("allowed_chat_ids") or []
    print("Allowlist\t%s" % ("terbuka" if not allowed else "%d ID" % len(allowed)))


def ids(action, field, value=None):
    data = raw_config()
    current = data.get(field) or []
    current = [str(item) for item in current]
    if action == "list":
        if not current:
            print("(kosong — %s)" % ("akses terbuka kepada semua" if field == "allowed_chat_ids" else "tiada admin"))
        else:
            for item in current:
                print(item)
        return
    if action == "add":
        if value not in current:
            current.append(value)
            data[field] = [int(x) if x.lstrip("-").isdigit() else x for x in current]
            save_config(data)
            print("ID %s ditambah." % value)
        else:
            print("ID %s sudah ada." % value)
        return
    if action == "remove":
        if value not in current:
            print("ID %s tiada dalam senarai." % value)
            return
        current.remove(value)
        data[field] = [int(x) if x.lstrip("-").isdigit() else x for x in current]
        save_config(data)
        print("ID %s dibuang." % value)
        if field == "allowed_chat_ids" and not current:
            print("AMARAN: allowlist kosong; akses kini terbuka kepada semua chat.")
        return
    if action == "clear":
        data[field] = []
        save_config(data)
        print("Senarai dikosongkan.")
        if field == "allowed_chat_ids":
            print("AMARAN: akses kini terbuka kepada semua chat.")
        return
    raise SystemExit("Operasi ID tak dikenali.")


def set_token():
    token = sys.stdin.read().rstrip("\r\n")
    if not token.strip():
        raise SystemExit("Token kosong — tak disimpan.")
    data = raw_config()
    data["bot_token"] = token.strip()
    save_config(data)
    print("Token disimpan dalam %s." % CONF)


def note(action):
    config = cfg()
    if action == "show":
        value = bot.read_note(config)
        print(value if value else "(note umum kosong)")
    elif action == "set":
        value = sys.stdin.read().rstrip("\r\n")
        limit = int(config.get("note_max_len", 800))
        if not value.strip():
            raise SystemExit("Note kosong — tak disimpan.")
        if len(value) > limit:
            raise SystemExit("Note %d aksara; had ialah %d." % (len(value), limit))
        bot.save_note(config, value)
        print("Note umum disimpan (%d aksara)." % len(value))
    elif action == "delete":
        print("Note umum dipadam." if bot.clear_note(config) else "Tiada note untuk dipadam.")


def config_items():
    return bot.all_configs(cfg())


def config_list(details=False):
    config = cfg()
    items = config_items()
    if not items:
        print("(tiada config VLESS yang sah dalam CONFIG LIST)")
        return
    for index, (provider, emoji, entry) in enumerate(items, 1):
        name = bot.display_name(config, entry)
        if details:
            print("[%d] %s %s | host=%s | proto=%s | path=%s | extra=%s" %
                  (index, emoji, name, entry["addr"], entry["proto"], entry["path"], entry["extra"]))
        else:
            print("[%d] %s %s — %s" % (index, emoji, provider.upper(), name))


def config_note(action, index):
    config = cfg()
    items = config_items()
    try:
        provider, _emoji, entry = items[int(index) - 1]
    except (ValueError, IndexError):
        raise SystemExit("Nombor config tak sah.")
    if action == "show":
        value = bot.get_cnote(config, provider, entry["name"])
        print(value if value else "(note config kosong)")
    elif action == "set":
        value = sys.stdin.read().rstrip("\r\n")
        limit = int(config.get("note_max_len", 800))
        if not value.strip():
            raise SystemExit("Note kosong — tak disimpan.")
        if len(value) > limit:
            raise SystemExit("Note %d aksara; had ialah %d." % (len(value), limit))
        bot.set_cnote(config, provider, entry["name"], value)
        print("Note disimpan untuk %s." % entry["name"])
    elif action == "delete":
        print("Note config dipadam." if bot.del_cnote(config, provider, entry["name"])
              else "Config ini tiada note.")


def show_config():
    data = raw_config()
    safe = dict(data)
    safe["bot_token"] = data.get("bot_token") or "[belum diset]"
    print(json.dumps(safe, ensure_ascii=False, indent=2))
    print("\nConfig dalam CONFIG LIST:")
    config_list(details=True)


def main(argv):
    if not argv:
        raise SystemExit("Guna: manage.py summary|ids|token|note|config-list|config-note|show-config")
    action = argv[0]
    if action == "summary":
        summary()
    elif action == "ids":
        ids(argv[1], argv[2], argv[3] if len(argv) > 3 else None)
    elif action == "token":
        set_token()
    elif action == "note":
        note(argv[1])
    elif action == "config-list":
        config_list(details=len(argv) > 1 and argv[1] == "details")
    elif action == "config-note":
        config_note(argv[1], argv[2])
    elif action == "show-config":
        show_config()
    else:
        raise SystemExit("Pilihan tak dikenali: %s" % action)


if __name__ == "__main__":
    main(sys.argv[1:])
