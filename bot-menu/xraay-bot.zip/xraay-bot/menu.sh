#!/bin/bash
set -uo pipefail

BASE="/opt/xraay-bot-menu"
INSTALLER="$BASE/install.sh"
MANAGER="$BASE/manage.py"
BOT_SOURCE="$BASE/bot.py"
BOT_BIN="/usr/local/bin/xraay-bot"
CONF="/etc/xraay-bot/config.json"
SERVICE="xraay-bot"
c_cyan='\e[36m'; c_green='\e[32m'; c_red='\e[31m'; c_reset='\e[0m'
info() { echo -e "${c_cyan}[*]${c_reset} $*"; }
ok()   { echo -e "${c_green}[✓]${c_reset} $*"; }
err()  { echo -e "${c_red}[x]${c_reset} $*" >&2; }

[ "$(id -u)" -eq 0 ] || { err "Jalankan menu sebagai root: sudo xraay-bot-menu"; exit 1; }
[ -x "$INSTALLER" ] && [ -f "$MANAGER" ] || { err "Fail menu tak lengkap. Pasang semula menggunakan install.sh."; exit 1; }
command -v python3 >/dev/null 2>&1 || { err "python3 tak dijumpai. Pasang semula menu untuk memasang keperluannya."; exit 1; }

has_service() {
    [ -f /etc/systemd/system/xraay-bot.service ] || systemctl list-unit-files xraay-bot.service --no-legend 2>/dev/null | grep -q xraay-bot
}
manage() { XRAY_BOT_CONFIG="$CONF" python3 "$MANAGER" "$@"; }
pause_menu() { echo; read -rp "Tekan Enter untuk kembali..." _; }
restart_if_active() {
    if systemctl is-active --quiet "$SERVICE" 2>/dev/null; then
        if systemctl restart "$SERVICE"; then ok "Bot direstart supaya tetapan baharu digunakan."
        else err "Bot tak berjaya direstart. Semak log melalui pilihan 11."; fi
    fi
}
read_note_text() {
    local line
    NOTE_TEXT=""
    echo "Taip note; untuk berbilang baris, taip END pada baris terakhir."
    while IFS= read -r line; do
        [[ "$line" == "END" ]] && break
        [[ -n "$NOTE_TEXT" ]] && NOTE_TEXT+=$'\n'
        NOTE_TEXT+="$line"
        if (( ${#NOTE_TEXT} > 800 )); then
            err "Note melebihi had 800 aksara."
            NOTE_TEXT=""
            return 1
        fi
    done
    [[ -n "$NOTE_TEXT" ]]
}
show_status() {
    if systemctl is-active --quiet "$SERVICE" 2>/dev/null; then
        echo -e "${c_green}● RUNNING${c_reset}"
    elif has_service; then
        echo -e "${c_red}● STOPPED${c_reset}"
    else echo "● NOT INSTALLED"; fi
}

draw_menu() {
    local status summary token="belum diset" admins="0 ID" general_note="tiada" config_notes="0" configs="0 telco / 0 config"
    if systemctl is-active --quiet "$SERVICE" 2>/dev/null; then status="${c_green}● RUNNING${c_reset}"
    elif has_service; then status="${c_red}● STOPPED${c_reset}"
    else status="● NOT INSTALLED"; fi
    summary="$(manage summary 2>/dev/null || true)"
    while IFS=$'\t' read -r key value; do
        case "$key" in
            Token) token="$value" ;;
            Admin) admins="$value" ;;
            "Note umum") general_note="$value" ;;
            "Note config") config_notes="$value" ;;
            "Config list") configs="$value" ;;
        esac
    done <<< "$summary"
    clear 2>/dev/null || true
    echo -e "   ${c_cyan}╔══════════════════════════════════════════════╗${c_reset}"
    echo -e "   ${c_cyan}║      BOT CONFIG LIST VLESS — PANEL URUS      ║${c_reset}"
    echo -e "   ${c_cyan}╚══════════════════════════════════════════════╝${c_reset}"
    echo
    echo -e "   Status       : $status"
    echo "   Token        : $token"
    echo "   Admin        : $admins"
    echo "   Note umum    : $general_note"
    echo "   Note config  : $config_notes"
    echo "   Config list  : $configs"
    echo
    echo "   ┌── PEMASANGAN ────────────────────────────────"
    echo "   │  [1] Install / Update bot"
    echo "   │  [2] Set / Tukar token bot"
    echo "   └──────────────────────────────────────────────"
    echo "   ┌── PERKHIDMATAN ──────────────────────────────"
    echo "   │  [3] Status terperinci"
    echo "   │  [4] Start / Stop / Restart"
    echo "   └──────────────────────────────────────────────"
    echo "   ┌── AKSES ─────────────────────────────────────"
    echo "   │  [5] Urus admin"
    echo "   │  [6] Urus allowlist pengguna"
    echo "   └──────────────────────────────────────────────"
    echo "   ┌── NOTE ──────────────────────────────────────"
    echo "   │  [7] Note umum"
    echo "   │  [8] Note per-config"
    echo "   └──────────────────────────────────────────────"
    echo "   ┌── LAIN-LAIN ──────────────────────────────────"
    echo "   │  [9] Uji carian User ID"
    echo "   │ [10] Papar config semasa"
    echo "   │ [11] Log bot"
    echo "   │ [12] Uninstall"
    echo "   │  [0] Keluar"
    echo "   └──────────────────────────────────────────────"
    echo
}

manage_ids() {
    local field="$1" title="$2" action id answer
    while true; do
        clear 2>/dev/null || true
        echo "── $title ──"
        echo "Senarai semasa:"
        manage ids list "$field"
        echo
        echo "  [1] Tambah ID"
        echo "  [2] Buang ID"
        [[ "$field" == "allowed_chat_ids" ]] && echo "  [3] Kosongkan allowlist (akses terbuka)"
        echo "  [0] Kembali"
        read -rp "Pilih: " action
        case "$action" in
            1)
                read -rp "Masukkan chat ID: " id
                if [[ "$id" =~ ^-?[0-9]+$ ]]; then
                    manage ids add "$field" "$id"
                    restart_if_active
                else err "ID mesti nombor integer (ID group boleh bermula dengan tanda -)."; fi
                pause_menu
                ;;
            2)
                read -rp "Masukkan chat ID untuk dibuang: " id
                if [[ "$id" =~ ^-?[0-9]+$ ]]; then
                    if [[ "$field" == "allowed_chat_ids" ]]; then
                        read -rp "Jika ini ID terakhir, akses akan terbuka kepada semua. Teruskan? [y/N]: " answer
                        [[ "${answer,,}" == "y" ]] || continue
                    fi
                    manage ids remove "$field" "$id"
                    restart_if_active
                else err "ID mesti nombor integer."; fi
                pause_menu
                ;;
            3)
                if [[ "$field" == "allowed_chat_ids" ]]; then
                    read -rp "Allowlist kosong bermaksud sesiapa boleh guna bot. Teruskan? [y/N]: " answer
                    if [[ "${answer,,}" == "y" ]]; then
                        manage ids clear "$field"
                        restart_if_active
                    fi
                    pause_menu
                fi
                ;;
            0) return ;;
            *) err "Pilihan tak sah."; pause_menu ;;
        esac
    done
}

manage_notes() {
    local action answer
    while true; do
        clear 2>/dev/null || true
        echo "── NOTE UMUM ──"
        echo "  [1] Papar note"
        echo "  [2] Set / Tukar note"
        echo "  [3] Padam note"
        echo "  [0] Kembali"
        read -rp "Pilih: " action
        case "$action" in
            1) manage note show; pause_menu ;;
            2) if read_note_text; then printf '%s' "$NOTE_TEXT" | manage note set; fi; pause_menu ;;
            3)
                read -rp "Padam note umum? [y/N]: " answer
                [[ "${answer,,}" == "y" ]] && manage note delete
                pause_menu
                ;;
            0) return ;;
            *) err "Pilihan tak sah."; pause_menu ;;
        esac
    done
}

manage_config_notes() {
    local index action
    clear 2>/dev/null || true
    echo "── NOTE PER-CONFIG ──"
    manage config-list
    echo
    read -rp "Nombor config (0 untuk kembali): " index
    [[ "$index" == "0" || -z "$index" ]] && return
    echo "  [1] Papar note"
    echo "  [2] Set / Tukar note"
    echo "  [3] Padam note"
    read -rp "Pilih tindakan: " action
    case "$action" in
        1) manage config-note show "$index" ;;
        2) if read_note_text; then printf '%s' "$NOTE_TEXT" | manage config-note set "$index"; fi ;;
        3) manage config-note delete "$index" ;;
        *) err "Pilihan tak sah." ;;
    esac
    pause_menu
}

service_menu() {
    local action
    while true; do
        clear 2>/dev/null || true
        echo "── PERKHIDMATAN BOT ──"
        echo "Status: $(systemctl is-active "$SERVICE" 2>/dev/null || echo 'belum dipasang')"
        echo "  [1] Start dan aktifkan auto-start"
        echo "  [2] Stop dan nyahaktifkan auto-start"
        echo "  [3] Restart"
        echo "  [0] Kembali"
        read -rp "Pilih: " action
        case "$action" in
            1) if has_service && systemctl enable --now "$SERVICE"; then ok "Bot dimulakan."; else err "Bot belum dipasang atau gagal dimulakan."; fi; pause_menu ;;
            2) if has_service && systemctl disable --now "$SERVICE"; then ok "Bot dihentikan dan auto-start dinyahaktifkan."; else info "Bot belum dipasang."; fi; pause_menu ;;
            3) if has_service && systemctl restart "$SERVICE"; then ok "Bot direstart."; else err "Bot belum dipasang atau gagal direstart."; fi; pause_menu ;;
            0) return ;;
            *) err "Pilihan tak sah."; pause_menu ;;
        esac
    done
}

status_details() {
    clear 2>/dev/null || true
    echo "── STATUS TERPERINCI ──"
    show_status
    if has_service; then
        echo "Auto-start  : $(systemctl is-enabled "$SERVICE" 2>/dev/null || echo 'disabled')"
        systemctl status "$SERVICE" --no-pager || true
    else echo "Service     : belum dipasang"; fi
    echo
    echo "Ringkasan konfigurasi:"
    manage summary
    pause_menu
}

set_token() {
    local token
    read -rp "Token bot baharu: " token
    [[ -n "$token" ]] || { err "Token kosong."; return; }
    printf '%s' "$token" | manage token || return
    unset token
    restart_if_active
}

test_user_lookup() {
    local uid
    read -rp "Masukkan User ID / UUID: " uid
    [[ "$uid" =~ ^[A-Za-z0-9_-]{4,120}$ ]] || { err "Format User ID tak sah."; return; }
    echo
    if [[ -x "$BOT_BIN" ]]; then XRAY_BOT_CONFIG="$CONF" "$BOT_BIN" --dump "$uid"
    else XRAY_BOT_CONFIG="$CONF" python3 "$BOT_SOURCE" --dump "$uid"; fi
}

while true; do
    draw_menu
    read -rp "   Pilih tindakan [0-12]: " choice
    case "$choice" in
        1) "$INSTALLER" --install-bot; pause_menu ;;
        2) set_token; pause_menu ;;
        3) status_details ;;
        4) service_menu ;;
        5) manage_ids admin_ids "URUS ADMIN" ;;
        6) manage_ids allowed_chat_ids "URUS ALLOWLIST PENGGUNA" ;;
        7) manage_notes ;;
        8) manage_config_notes ;;
        9) test_user_lookup; pause_menu ;;
        10) clear 2>/dev/null || true; echo "── CONFIG SEMASA ──"; manage show-config; pause_menu ;;
        11)
            if has_service; then
                echo "Paparan log langsung. Tekan Ctrl+C untuk kembali ke menu."
                journalctl -u "$SERVICE" -f || true
            else info "Bot belum dipasang."; fi
            pause_menu
            ;;
        12)
            read -rp "Buang service dan program bot? Config/note dikekalkan secara lalai. [y/N]: " answer
            [[ "${answer,,}" == "y" ]] && "$INSTALLER" --uninstall-bot
            pause_menu
            ;;
        0) exit 0 ;;
        *) err "Pilihan tak sah."; pause_menu ;;
    esac
done
