#!/bin/bash
# Pasang menu pengurus sahaja secara lalai. Bot hanya dipasang apabila dipilih.
set -euo pipefail

BOT_BIN="/usr/local/bin/xraay-bot"
CONF_DIR="/etc/xraay-bot"
CONF_FILE="$CONF_DIR/config.json"
SERVICE="/etc/systemd/system/xraay-bot.service"
MENU_HOME="/opt/xraay-bot-menu"
MENU_CMD="/usr/local/sbin/xraay-bot-menu"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

c_green='\e[32m'; c_red='\e[31m'; c_cyan='\e[36m'; c_reset='\e[0m'
info() { echo -e "${c_cyan}[*]${c_reset} $*"; }
ok()   { echo -e "${c_green}[✓]${c_reset} $*"; }
err()  { echo -e "${c_red}[x]${c_reset} $*" >&2; }

[ "$(id -u)" -eq 0 ] || { err "Kena run sebagai root."; exit 1; }

ensure_python() {
    if command -v python3 >/dev/null 2>&1; then
        ok "python3: $(python3 --version 2>&1)"
        return
    fi
    info "python3 tiada, memasang..."
    if command -v apt-get >/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive apt-get update -qq
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3
    elif command -v yum >/dev/null 2>&1; then
        yum install -y -q python3
    else
        err "python3 tiada dan tiada package manager dikenali."
        exit 1
    fi
}

install_menu() {
    for f in bot.py manage.py menu.sh xraay-bot.service config.example.json; do
        [ -f "$HERE/$f" ] || { err "$f tak jumpa dalam $HERE"; exit 1; }
    done

    ensure_python
    install -d -m 755 "$MENU_HOME"
    install -m 755 "$HERE/install.sh" "$MENU_HOME/install.sh"
    install -m 755 "$HERE/menu.sh" "$MENU_HOME/menu.sh"
    install -m 644 "$HERE/manage.py" "$MENU_HOME/manage.py"
    install -m 755 "$HERE/bot.py" "$MENU_HOME/bot.py"
    install -m 644 "$HERE/xraay-bot.service" "$MENU_HOME/xraay-bot.service"
    install -m 644 "$HERE/config.example.json" "$MENU_HOME/config.example.json"
    install -d -m 755 "$(dirname "$MENU_CMD")"
    ln -sfn "$MENU_HOME/menu.sh" "$MENU_CMD"
    ok "Menu pengurus dipasang: $MENU_CMD"
    info "Bot belum dipasang atau dijalankan."
    echo "Jalankan menu pada bila-bila masa dengan: xraay-bot-menu"
}

install_bot() {
    ensure_python
    [ -f "$HERE/bot.py" ] || { err "bot.py tak jumpa dalam $HERE"; exit 1; }
    [ -f "$HERE/xraay-bot.service" ] || { err "Fail service tak jumpa."; exit 1; }

    if ! command -v systemctl >/dev/null 2>&1; then
        err "systemd/systemctl tak dijumpai pada VPS ini."
        exit 1
    fi

    if [ ! -d /etc/xray/configlist ]; then
        info "Amaran: /etc/xray/configlist belum wujud."
        info "Bot akan papar 'tiada config' sehingga config ditambah."
    fi
    if [ ! -f /root/log-install.txt ]; then
        info "Amaran: /root/log-install.txt tak jumpa — bot guna port lalai (443/80)."
    fi

    mkdir -p "$CONF_DIR"
    if [ -f "$CONF_FILE" ]; then
        info "Config sedia ada dikesan — dikekalkan."
        cp -a "$CONF_FILE" "$CONF_FILE.bak.$(date +%s)"
    else
        cp "$HERE/config.example.json" "$CONF_FILE"
    fi

    current_token="$(python3 -c 'import json,sys; print((json.load(open(sys.argv[1])).get("bot_token") or ""))' "$CONF_FILE")"
    if [[ -z "$current_token" ]]; then
        echo
        read -rp "Token bot dari @BotFather: " token
        [[ -n "$token" ]] || { err "Token belum diset. Guna pilihan 2 dalam menu dahulu."; exit 1; }
        printf '%s' "$token" | python3 -c 'import json,sys,os; p=sys.argv[1]; d=json.load(open(p)); d["bot_token"]=sys.stdin.read().strip(); t=p+".tmp"; open(t,"w").write(json.dumps(d,ensure_ascii=False,indent=2)+"\n"); os.chmod(t,0o600); os.replace(t,p)' "$CONF_FILE"
        unset token
    fi
    chmod 600 "$CONF_FILE"

    install -m 755 "$HERE/bot.py" "$BOT_BIN"
    install -m 644 "$HERE/xraay-bot.service" "$SERVICE"
    systemctl daemon-reload
    systemctl enable xraay-bot >/dev/null 2>&1
    systemctl restart xraay-bot

    sleep 2
    if systemctl is-active --quiet xraay-bot; then
        ok "Bot berjaya dipasang dan sedang berjalan."
        echo "Ujian tanpa Telegram: xraay-bot --dump <USER_ID>"
        echo "Log: journalctl -u xraay-bot -f"
    else
        err "Bot gagal start. Semak: journalctl -u xraay-bot -n 50 --no-pager"
        exit 1
    fi
}

uninstall_bot() {
    info "Menghentikan dan membuang service serta program bot..."
    systemctl stop xraay-bot 2>/dev/null || true
    systemctl disable xraay-bot 2>/dev/null || true
    rm -f "$SERVICE" "$BOT_BIN"
    systemctl daemon-reload 2>/dev/null || true
    ok "Bot dibuang. Menu pengurus kekal dipasang."

    read -rp "Buang juga config dan note bot? [y/N] : " ans
    if [[ "${ans,,}" == "y" ]]; then
        rm -rf "$CONF_DIR" /var/lib/xraay-bot
        ok "Config dan note bot dibuang."
    else
        info "Config dan note dikekalkan untuk pemasangan semula."
    fi
}

uninstall_menu() {
    rm -f "$MENU_CMD"
    rm -rf "$MENU_HOME"
    ok "Menu pengurus dibuang. Bot yang sedang dipasang tidak disentuh."
}

case "${1:-}" in
    "") install_menu ;;
    --install-menu) install_menu ;;
    --install-bot) install_bot ;;
    --uninstall-bot|--uninstall) uninstall_bot ;;
    --uninstall-menu) uninstall_menu ;;
    *)
        err "Pilihan tak dikenali: $1"
        echo "Guna tanpa pilihan untuk pasang menu sahaja."
        exit 2
        ;;
esac
