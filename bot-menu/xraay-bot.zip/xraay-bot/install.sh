#!/bin/bash
# ============================================================
#  Installer xraay-bot — Bot Telegram CONFIG LIST (Xray VLESS)
# ------------------------------------------------------------
#  Guna:
#     bash install.sh                    # install / kemaskini
#     bash install.sh --uninstall        # buang sepenuhnya
# ============================================================
set -euo pipefail

BOT_BIN="/usr/local/bin/xraay-bot"
CONF_DIR="/etc/xraay-bot"
CONF_FILE="$CONF_DIR/config.json"
SERVICE="/etc/systemd/system/xraay-bot.service"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

c_green='\e[32m'; c_red='\e[31m'; c_cyan='\e[36m'; c_reset='\e[0m'
info() { echo -e "${c_cyan}[*]${c_reset} $*"; }
ok()   { echo -e "${c_green}[✓]${c_reset} $*"; }
err()  { echo -e "${c_red}[x]${c_reset} $*" >&2; }

[ "$(id -u)" -eq 0 ] || { err "Kena run sebagai root."; exit 1; }

# ---------------- UNINSTALL ----------------
if [[ "${1:-}" == "--uninstall" ]]; then
    info "Membuang xraay-bot..."
    systemctl stop xraay-bot 2>/dev/null || true
    systemctl disable xraay-bot 2>/dev/null || true
    rm -f "$SERVICE" "$BOT_BIN" /usr/local/bin/xraay-bot-menu
    systemctl daemon-reload
    read -rp "Buang juga config ($CONF_FILE)? [y/N] : " ans
    [[ "${ans,,}" == "y" ]] && rm -rf "$CONF_DIR"
    ok "Selesai. Bot telah dibuang."
    exit 0
fi

# ---------------- SEMAK PYTHON ----------------
if ! command -v python3 >/dev/null 2>&1; then
    info "python3 tiada, memasang..."
    if command -v apt-get >/dev/null 2>&1; then
        DEBIAN_FRONTEND=noninteractive apt-get update -qq
        DEBIAN_FRONTEND=noninteractive apt-get install -y -qq python3
    elif command -v yum >/dev/null 2>&1; then
        yum install -y -q python3
    else
        err "python3 tiada dan tiada package manager dikenali."; exit 1
    fi
fi
ok "python3: $(python3 --version 2>&1)"

# ---------------- SEMAK SUMBER ----------------
[ -f "$HERE/bot.py" ] || { err "bot.py tak jumpa dalam $HERE"; exit 1; }

# ---------------- SEMAK CONFIG LIST ----------------
if [ ! -d /etc/xray/configlist ]; then
    info "Amaran: /etc/xray/configlist belum wujud."
    info "Bot akan papar 'tiada config' sehingga kau tambah config dalam panel."
fi
if [ ! -f /root/log-install.txt ]; then
    info "Amaran: /root/log-install.txt tak jumpa — bot guna port lalai (443/80)."
fi

# ---------------- TOKEN ----------------
mkdir -p "$CONF_DIR"

if [ -f "$CONF_FILE" ]; then
    info "Config sedia ada dikesan — dikekalkan."
    cp -a "$CONF_FILE" "$CONF_FILE.bak.$(date +%s)"
else
    echo
    echo "Pilih cara isi token bot:"
    echo "  1) Tampal token sekarang"
    echo "  2) Kekal config contoh (isi token sendiri kemudian)"
    read -rp "Pilihan [1/2] : " pilih

    if [[ "$pilih" == "1" ]]; then
        read -rp "Token bot (dari @BotFather) : " token
        [[ -n "$token" ]] || { err "Token kosong."; exit 1; }
        cat > "$CONF_FILE" <<EOF
{
  "bot_token": "$token",
  "allowed_chat_ids": [],
  "admin_ids": [],
  "configlist_dir": "/etc/xray/configlist",
  "xray_configs": [
    "/usr/local/etc/xray/config.json",
    "/usr/local/etc/xray/none.json"
  ],
  "log_install": "/root/log-install.txt",
  "fragment_style": "name",
  "display_server_tag": false,
  "note_file": "/var/lib/xraay-bot/note.txt",
  "note_max_len": 800,
  "config_note_file": "/var/lib/xraay-bot/config-notes.json",
  "poll_timeout": 50,
  "ports": {
    "ws_tls": "443",
    "ws_none": "80",
    "hu_tls": "443",
    "hu_none": "80",
    "xhttp_tls": "443",
    "xhttp_none": "80"
  }
}
EOF
    else
        cp "$HERE/config.example.json" "$CONF_FILE"
        info "Jangan lupa isi bot_token dalam $CONF_FILE"
    fi
fi
chmod 600 "$CONF_FILE"
ok "Config: $CONF_FILE"

# ---------------- PASANG ----------------
install -m 755 "$HERE/bot.py" "$BOT_BIN"
ok "Binari: $BOT_BIN"

if [ -f "$HERE/menu.sh" ]; then
    install -m 755 "$HERE/menu.sh" /usr/local/bin/xraay-bot-menu
    ok "Menu urus: /usr/local/bin/xraay-bot-menu"
fi

install -m 644 "$HERE/xraay-bot.service" "$SERVICE"
systemctl daemon-reload
systemctl enable xraay-bot >/dev/null 2>&1
systemctl restart xraay-bot

sleep 2
if systemctl is-active --quiet xraay-bot; then
    ok "Bot BERJALAN sebagai service."
else
    err "Bot gagal start. Semak log:"
    echo "    journalctl -u xraay-bot -n 50 --no-pager"
    exit 1
fi

echo
echo -e "${c_green}══════════════════════════════════════════${c_reset}"
echo "  Menu urus (semua dalam satu):"
echo "    xraay-bot-menu"
echo
echo "  Ujian pantas (tanpa Telegram):"
echo "    xraay-bot --dump <USER_ID>"
echo
echo "  Panel admin (tambah Note pada reply):"
echo "    - Hantar /admin pada bot untuk dapat chat ID kau"
echo "    - Masukkan ID tu dalam admin_ids (/etc/xraay-bot/config.json)"
echo "    - systemctl restart xraay-bot"
echo
echo "  Log langsung:"
echo "    journalctl -u xraay-bot -f"
echo -e "${c_green}══════════════════════════════════════════${c_reset}"
